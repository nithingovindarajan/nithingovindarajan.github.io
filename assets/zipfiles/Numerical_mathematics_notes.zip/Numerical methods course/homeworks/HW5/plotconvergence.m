function [  ] = plotconvergence( func )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

if strcmp(func,'smooth')

    f = @(x)(  exp(- x .^2) );
    area_exact = sqrt(pi)* erf(1);

elseif strcmp(func,'nonsmooth')
    
    f = @(x)(-abs(x)+1);
    area_exact = 1;
 
end


N = 200;
error_gauss = zeros(N,1);
error_simpson = zeros(N,1);
for n=1:N
   area_gauss = gaussquadrature(f,n) ;
   area_simpson = simpsonquadrature( f , n );
   error_gauss(n) = abs(area_exact - area_gauss);
   error_simpson(n) = abs(area_exact - area_simpson);
end



figure 
semilogy(1:N,error_gauss)
hold on
semilogy(1:N,error_simpson) 
xlabel('n')
ylabel('error')
end

