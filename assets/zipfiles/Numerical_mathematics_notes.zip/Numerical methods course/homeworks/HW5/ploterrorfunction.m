function [  ] = ploterrorfunction(  method, n  )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

x = -1:0.001:1;
if strcmp(method,'simpson')
    
    en =zeros(size(x));
    if  mod(n,2) == 1
       
        h = 2/n; 
        X= [-h/2; 0; h/2]; 
        Y = 1-abs(X); 
        for ii = 1:length(x)
            if  x(ii)>= -h/2 &&  x(ii)<= h/2
                   
                en(ii) = abs((-abs(x(ii))+1) - lagrangeinterp( x(ii), X, Y));
            
            end
        end
        
        figure
        plot(x,en)
        xlabel('x')
        ylabel('e_n')
        
    end
    
    
    
elseif strcmp(method,'gaussian')
   dispod = 'hello'
   % compute legendre nodes 
   beta = .5./sqrt(1-(2*(1:n)).^(-2));   
   T = diag(beta,1) + diag(beta,-1);     
   [V,D] = eig(T);                       
   X = diag(D); X = sort(X);             
   
   
   y =  lagrangeinterp( x, X, -abs(X)+1 );
   
   en = abs(y-(1-abs(x)) )
end
 
  
  
    

end






function [ y_int ] = lagrangeinterp( x_int, X, Y )
    
% number of points:
n = length(X);

% Pre-compute weights:
W = X*ones(1,n) - ones(n,1)*transpose(X)+eye(n);
W = 1 ./ prod(W,2);


% Initialize array of zeros for output
y_int = zeros(size(x_int));

% evaluate function 
for k=1:length(x_int)
    
    % check if interpolation point is not equal to one of the data points
    % to prevent division by zero.
    m = find(X == x_int(k));
    if isempty(m)

        diff = x_int(k)-X;
        y_int(k) = prod(diff) * transpose( 1./diff ) * (W .* Y);

    else
        
        % if it is, the value is simply:
        y_int(k) = Y(m);

    end
    
end

end


