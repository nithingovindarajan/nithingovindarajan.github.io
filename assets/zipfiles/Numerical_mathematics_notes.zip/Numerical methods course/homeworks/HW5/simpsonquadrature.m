function [ I  ] = simpsonquadrature( f , n )
%SIMPSONQUADRATURE Summary of this function goes here
%   Detailed explanation goes here

xnodes = linspace(-1,1,n+1);
h = 2/n;

I = 0;
for l=1:n
 deltaI = (h/6)*( f(xnodes(l)) +   4*f(0.5*(xnodes(l)+xnodes(l+1)))  +   f(xnodes(l+1)) );
 I = I + deltaI;
end

