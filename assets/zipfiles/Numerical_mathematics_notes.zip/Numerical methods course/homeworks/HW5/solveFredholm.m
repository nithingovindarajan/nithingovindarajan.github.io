function [  ] = solveFredholm(lambda, n )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

% 
x_eval = 0:0.001:1;

x_grid = 0:1/n:1;


% Solve fredholm equation. Fredholm equation
f =zeros(n+1,1);
for i = 0:n
    f(i+1) = f_func(x_grid(i+1));
end



% true solution
c = [1, 1; exp(sqrt(lambda)), exp(-sqrt(lambda))] \ [1/lambda; 1/lambda];
utrue = c(1)*exp(sqrt(lambda).*x_eval) + c(2)*exp(-sqrt(lambda).*x_eval) - 1/lambda;

A = zeros(n+1,n+1);
for i=0:n
    for j=0:n
        if j==0 || j==n
            A(i+1,j+1) = (1/(2*n)) * kernel(x_grid(i+1), x_grid(j+1));
        else
            A(i+1,j+1) = (1/(n))*kernel(x_grid(i+1), x_grid(j+1));    
        end
        
    end
end
% solve fredholm equation
u_approx = (eye(n+1) - lambda * A) \ f;

u_approxinterp = interp1(x_grid ,u_approx,x_eval);

% plot figure
figure
plot(x_eval,(utrue-u_approxinterp))

xlabel('x')
ylabel('error')


end

function [K] = kernel(x,y)


if x<= y
    K = x*(y-1);
elseif y<x
    K = y*(x-1);
end

end


function [fofx] = f_func(x)

fofx = 0.5 .* x .* (x-1);

end
