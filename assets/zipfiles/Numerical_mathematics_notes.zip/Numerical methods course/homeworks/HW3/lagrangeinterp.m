function [ y_int ] = lagrangeinterp( x_int, X, Y )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

% number of points:
n = length(X);

% Pre-compute weights:
W = X*ones(1,n) - ones(n,1)*transpose(X)+eye(n);
W = 1 ./ prod(W,2);



% Initialize array of zeros for output
y_int = zeros(size(x_int));

% evaluate function 
for k=1:length(x_int)
    
    % check if interpolation point is not equal to one of the data points
    % to prevent division by zero.
    m = find(X == x_int(k));
    if isempty(m)

        diff = x_int(k)-X;
        y_int(k) = prod(diff) * transpose( 1./diff ) * (W .* Y);
        
    else
        
        % if it is, the value is simply:
        y_int(k) = Y(m);

    end
    
end


end

