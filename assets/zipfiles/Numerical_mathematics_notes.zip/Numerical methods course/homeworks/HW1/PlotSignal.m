function [ ] = PlotSignal( )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

t= 0:0.001:0.1; 
x = zeros(size(t)); 

for l=1:length(x)  % 1 pts
    x(l) = sin(50 *pi * t(l))  + 0.25 * sin(226 * pi *t(l)) + 0.01 * t(l)^2; % 1 pts 
end


figure
plot(t,x) % 1pts
xlabel('t'); ylabel('x') % 1pts
title('Signal') % 1 pts



end

