function I = find_current(V,R1,R2,R3)

% matrix for Kirchhoff's rules
A = [-1 1 1 0;
      0 1 1 -1;
      R1 0 R3 0;
      R1 R2 0 0];    % 2 pts

% righthand side for Kirchhoff's rules
b = [0;0;V;V]; % 2 pts

% solve for currents
I = A\b; % 1pts

end
%find_current(1,2,3,4)

ans =

0.2692
0.1538
0.1154
0.2692
%
