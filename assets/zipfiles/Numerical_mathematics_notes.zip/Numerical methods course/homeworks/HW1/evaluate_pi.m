function [ out] = evaluate_pi( n )
%EVALUATE_PI Summary of this function goes here
%   Detailed explanation goes here

out = 1;

if n > 0

    a=1;
    for k=1:n
        a = a * k/(2*k+1)
        out = out + a;
    end
    
    
end


out = 2*out;

end

