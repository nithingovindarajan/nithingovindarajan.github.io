function [ ] = PlotSignal_vectorized( )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

t= 0:0.001:0.1;
x = sin(50 *pi * t)  + 0.25 * sin(226 * pi *t) + 0.01 * t.^2; % 2pts


figure
plot(t,x) % 1 pts
xlabel('t'); ylabel('x') % 1 pts
title('Signal') % 1pts



end

