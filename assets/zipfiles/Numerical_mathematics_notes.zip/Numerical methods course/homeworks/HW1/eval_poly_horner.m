function [ pofx ] = eval_poly_horner( x, a )
%EVAL_POLY_HORNER Summary of this function goes here
%   Detailed explanation goes here

pofx = a(end);
for k=1:(length(a)-1)
    pofx = a(end-k) + pofx*x;
end


end

