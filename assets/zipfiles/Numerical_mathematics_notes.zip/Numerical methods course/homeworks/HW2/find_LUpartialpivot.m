function [ P,L,U ] = find_LUpartialpivot( A)
%FIND_LUPARTIALPIVOT Summary of this function goes here
%   Detailed explanation goes here

% initialize permutatio matrix, start with Identity
P = 1:size(A,1);

% Initialize an array for L, the A will be converted to U.
L = eye(size(A));


for k = 1:(size(A,1)-1) 
    
    
    %%%  Perform an exchange permutation (i.e. the pivoting part) %%%
    % Find the index with the largest entry
    [~, l] = max(abs(A(k:end,k))); l = l+k-1;
   
    % update permutation matrix
    P([l k]) = P([k l]);
    % exchange rows of A
    A([k l],:) = A([l k],:);
   
    % exchange rows of L (notice that in the first iterate it just exhanges zeros )
    L([k l],:) =  L([l k],:);  L(:,[k l]) =  L(:,[l k]);
    
 
    %%% Perform the gaussian elimination step %%%
    % update the entries in L:
    L(k+1:end,k) = A(k+1:end,k) / A(k,k);
    
    % update the entries of A (or our future U):
    A(k+1:end,k+1:end) = A((k+1):end,(k+1):end) -  L(k+1:end,k) * A(k,(k+1):end); 
    A(k+1:end,k) = 0; 

end

U = A;




end

