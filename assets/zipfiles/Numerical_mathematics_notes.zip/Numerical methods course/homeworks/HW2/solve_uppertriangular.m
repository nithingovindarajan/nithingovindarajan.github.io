function [ x ] = solve_uppertriangular( A, b)
% - Numerical mathematics course 2019 - 

% We can use our solver for a lower triangular system by using an exchange
% permutation.
x = solve_lowertriangular(A(end:-1:1,end:-1:1),b(end:-1:1));

% Reverse the order of the entries again.
x = x(end:-1:1);


end