function [ x ] = solve_lowertriangular( A, b)
% - Numerical mathematics course 2019 - 

% Find length of vector
n = length(b);

% Initialize a vector of size n.
x = zeros(n,1);

% The forward substition 
x(1) = b(1)/A(1,1);
for k=2:n
    % Instead of writing an inner for loop, we can use Matlab's convenient
    % syntax to extract a sub-part of a matrix as follows:
    x(k) = (b(k) - A(k,1:k-1)*x(1:k-1))/ A(k,k);
end


end
