function [ x ] = solve_linearsystem( A, b )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

% Step 1: Find the LU factorizationn
[L,U] = find_LU(A);

% Step 2: Forward substitution of L
y = solve_lowertriangular(L,b);

% Step 3: Back substitution of U 
x = solve_uppertriangular(U,y);

end

