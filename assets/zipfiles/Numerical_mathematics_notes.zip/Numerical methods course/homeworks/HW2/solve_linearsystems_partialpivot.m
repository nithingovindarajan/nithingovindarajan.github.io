function [ x ] = solve_linearsystems_partialpivot( A,b )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


% Step 1: Find the LU factorizationn
[P,L,U] = find_LUpartialpivot(A);


% Step 2: Forward substitution of L
y = solve_lowertriangular(L,b(P));

% Step 3: Back substitution of U 
x = solve_uppertriangular(U,y);

end
