function [L, U] = find_LU(A)
% - Numerical mathematics course 2019 - 



% Initialize an array for L, the A will be converted to U.
L = eye(size(A));


for k = 1:(size(A,1)-1) 
   
    % update the entries in L:
    if A(k,k) ~= 0
        L(k+1:end,k) = A(k+1:end,k) / A(k,k);
    else
        disp('Encountered a zero pivot. LU factorization is not possible. Ignore the results.')
        break;
    end
    
    % update the entries of A (or our future U):
    A(k+1:end,k+1:end) = A((k+1):end,(k+1):end) -  L(k+1:end,k) * A(k,(k+1):end); 
    A(k+1:end,k) = 0; 

end

U = A;




end