function [ c ] = chebfit( x, y, d )

% construct chebyshev matrix
A = zeros(length(x),d+1);
for k = 0:d
A(:,k+1) = chebyshevT(k,x); 
end
  
% compute R and modified b
[ R, bhat ] = QRhouseholder( A, y );

% Back substition (it is okay to use backlash here...)
c = R \ bhat;


% plotting
xplot = (-1:0.01:1)';
A = zeros(length(xplot),d+1);
for k = 0:d
A(:,k+1) = chebyshevT(k,xplot); 
end
yplot = A*c;


%plot figure
plot(x,y,'x')
hold on
plot(xplot,yplot)
xlabel('x')
ylabel('y')


end



function [ R, bhat ] = QRhouseholder( A, b )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

for k=1:size(A,2)
    
    %construct v
    x = A(k:end , k);
    v = [sign(x(1))*norm(x);  zeros(size(A,1)-k,1)]-x;
    v = v/norm(v);
    
    % Update A
    A(k:end,k) = [sign(x(1))*norm(x);  zeros(size(A,1)-k,1)];
    A((k):end,(k+1):end) = A((k):end,(k+1):end) - 2*v * v'*A((k):end,(k+1):end);
    
    %update b
    b(k:end) = b(k:end)  - 2*v * v'* b(k:end);
end

R = A(1:size(A,2),1:size(A,2));
bhat = b(1:size(A,2));

end




