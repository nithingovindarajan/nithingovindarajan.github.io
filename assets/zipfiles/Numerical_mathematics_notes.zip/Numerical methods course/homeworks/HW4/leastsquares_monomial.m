function [ x ] = leastsquares_monomial(n)
%LEASTSQUARES_MONOMIAL Summary of this function goes here
%   Detailed explanation goes here


A = zeros(n,n);
for i = 1:n
   for j=1:n
       A(i,j)= 1 / (i+j-1);
   end
end

b = zeros(n,1);
for j=1:n
       b(j)= 1 / (3+j-1);
end

x = A \ b;

end

