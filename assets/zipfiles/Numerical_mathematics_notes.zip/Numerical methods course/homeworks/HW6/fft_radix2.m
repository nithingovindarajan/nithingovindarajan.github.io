function [ X ] = fft_radix2( x )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

X = (1/sqrt(length(x))) * fft_unnormalized(x);



function [X] = fft_unnormalized(x)

if length(x) == 1
      X = x;
else 
    
    if rem(length(x),2) ~= 0
       disp('Warning: length of vector is not a power of 2.')
    end
    
   yt = fft_unnormalized( x(1:2:length(x)) );
   yb = fft_unnormalized( x(2:2:length(x)) );
 
   d = transpose( exp( -2*pi*1i* (0:1:(length(yt)-1)) / length(x) ) );
   
   z = d .* yb;
   
   X = [yt+z;
        yt-z];

end


