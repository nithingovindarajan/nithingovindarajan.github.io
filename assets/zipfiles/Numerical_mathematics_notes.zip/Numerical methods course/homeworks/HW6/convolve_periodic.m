function [ c ] = convolve_periodic(a,b)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

n = length(a);
c = (1/sqrt(n))* fft(   (n* ifft(a) )   .*  ( sqrt(n)* ifft(b))  ); 

end

